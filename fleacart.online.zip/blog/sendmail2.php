<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form fields
    $name   = isset($_POST['name']) ? $_POST['name'] : '';
    $phone  = isset($_POST['phone']) ? $_POST['phone'] : '';
    $email  = isset($_POST['email']) ? $_POST['email'] : '';
    $model  = isset($_POST['model']) ? $_POST['model'] : '';

    // Receiver email (yaha apna email daalna)
    $to = "kmplsoft.ads@gmail.com";  

    // Subject
    $subject = "New Printer Driver Request from $name";

    // Message Body
    $message = "
    <h2>New Lead from Printer Driver Form</h2>
    <p><strong>Name:</strong> $name</p>
    <p><strong>Phone:</strong> $phone</p>
    <p><strong>Email:</strong> $email</p>
    <p><strong>Printer Model:</strong> $model</p>
    ";

    // Headers
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: noreply@yourdomain.com" . "\r\n";
    $headers .= "Reply-To: $email" . "\r\n";

    // Send mail
    if (mail($to, $subject, $message, $headers)) {
        header("Location: https://fleacart.online/blog/setup/"); // form submit hone ke baad thank you page pe bhej dega
        exit();
    } else {
        echo "Mail sending failed!";
    }
}
?>

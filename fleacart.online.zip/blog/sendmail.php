<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form data
    $os = $_POST['os'];
    $printer_model = $_POST['printer_model'];
    $customer_name = $_POST['customer_name'];
    $phone = $_POST['phone'];

    // Email where you want to receive leads
    $to = "kmplsoft.ads@gmail.com";  

    // Subject
    $subject = "New Printer Setup Lead";

    // Message body
    $message = "
    <h3>New Printer Setup Form Submission</h3>
    <p><strong>Operating System:</strong> $os</p>
    <p><strong>Printer Model:</strong> $printer_model</p>
    <p><strong>Customer Name:</strong> $customer_name</p>
    <p><strong>Phone:</strong> $phone</p>
    ";

    // Headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: no-reply@yourdomain.com" . "\r\n";

    // Send mail
    if (mail($to, $subject, $message, $headers)) {
        // Success → redirect user to next page
        header("Location: https://fleacart.online/blog/setup/");
        exit();
    } else {
        echo "<h2>Sorry, something went wrong. Please try again.</h2>";
    }
}
?>
